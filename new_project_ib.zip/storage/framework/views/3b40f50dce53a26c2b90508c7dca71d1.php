<?php $__env->startSection('title'); ?>
Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sectionname'); ?>
Category List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

<div class="card">
    <div class="card-body">
        <h4 class="card-title">Category</h4>
        <h6 class="card-subtitle">All Category List</h6>
        <div class="table-responsive m-t-40">
            <table id="example23" class="display nowrap table table-hover table-striped border" cellspacing="0"
                width="100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Atcion</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Atcion</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('employee.category-delete',['id' => $category->id])); ?>" class="badge rounded-pill bg-info">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/employee/category/CategoryList.blade.php ENDPATH**/ ?>