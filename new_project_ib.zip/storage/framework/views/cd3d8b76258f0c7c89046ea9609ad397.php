<?php $__env->startSection('title'); ?>
    Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sectionname'); ?>
    Add Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <h4 class="card-title">Product Add</h4>
                <form action="<?php echo e(route('employee.product-create')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label" for="validationServer01">Product Name</label>
                            <input type="text" class="form-control is-valid" name="name" id="validationServer01"
                                placeholder="Product Name" required>
                            <div class="valid-feedback">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="validationServer01">Category Name</label>
                                <select class="form-select is-valid" name="category_id" id="category_id">
                                    <option>Select an Option</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select><span class="bar"></span>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="validationServer01">Brand Name</label>
                                <select class="form-select is-valid" name="brand_id" id="brand_id">
                                    <option>Select an Option</option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select><span class="bar"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label class="form-label" for="validationServer01">Description Titles</label>
                                    <div id="title-description-fields">
                                        <div class="title-description-pair">
                                            <input type="text" class="form-control is-valid" name="description_title[]"
                                                placeholder="Description Title" required>
                                            <textarea class="textarea_editor form-control is-valid mb-3" name="description_detail[]" rows="3"
                                                placeholder="Enter description ..." required></textarea>
                                        </div>
                                    </div>
                                    <button type="button" id="add-title-description" class="btn btn-outline-primary">Add More
                                        Title & Description</button>
                                </div>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="validationServer01">Product Price</label>
                                <input type="number" class="form-control is-valid" name="price" id="validationServer01"
                                    placeholder="Product Name" required>
                                <div class="valid-feedback">
                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8 mb-3">
                            <div id="image-field" class="image">
                                <label class="form-label" for="validationServer02">Product Image</label>
                                <input type="file" class="form-control is-valid" name="image[]" id="validationServer02"
                                    placeholder="Image" required>
                                <div class="valid-feedback">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button type="button" id="add-image" class="btn btn-outline-primary">Add More Image</button>
                        </div>
                    </div>
                    <button class="btn btn-primary text-white" type="submit">Add Product</button>
                </form>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/employee/product/addProduct.blade.php ENDPATH**/ ?>