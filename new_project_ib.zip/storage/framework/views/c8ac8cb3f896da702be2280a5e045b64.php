<?php $__env->startSection('title'); ?>
    Brand
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sectionname'); ?>
    Brand List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Brand</h4>
            <h6 class="card-subtitle">All Brand List</h6>
            <div class="table-responsive m-t-40">
                <table id="example23" class="display nowrap table table-hover table-striped border" cellspacing="0"
                    width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Atcion</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Atcion</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($brand->name); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($brand->image)); ?>" alt="" height="100">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.brand-delete', ['id' => $brand->id])); ?>" class="badge rounded-pill bg-info">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/admin/brand/brandList.blade.php ENDPATH**/ ?>