<?php $__env->startSection('body'); ?>
    

    <!-- Related Product Start -->
    
    <!-- Related Product end -->
    <!-------------------------------------------------------------------!>


                                    <!-- Ec breadcrumb start -->
    <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row ec_breadcrumb_inner">
                        <div class="col-md-6 col-sm-12">
                            <h2 class="ec-breadcrumb-title">Products</h2>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <!-- ec-breadcrumb-list start -->
                            <ul class="ec-breadcrumb-list">
                                <li class="ec-breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li class="ec-breadcrumb-item active">Products</li>
                            </ul>
                            <!-- ec-breadcrumb-list end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ec breadcrumb end -->

    <!-- Sart Single product -->
    <section class="ec-page-content section-space-p">
        <div class="container">
            <div class="row">
                <div class="ec-pro-rightside ec-common-rightside col-lg-9 order-lg-last col-md-12 order-md-first">

                    <!-- Single product content Start -->
                    <div class="single-pro-block">
                        <div class="single-pro-inner">
                            <div class="row">
                                <div class="single-pro-img">
                                    <div class="single-product-scroll">
                                        <?php
                                            $imageUrls = explode(',', $product->image);
                                            $countImages = count($imageUrls);
                                        ?>
                                        <div class="single-product-cover">
                                            <?php $__currentLoopData = $imageUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="single-slide zoom-image-hover">
                                                    <img class="img-responsive" src="<?php echo e(asset($imageUrl)); ?>" alt="">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="single-nav-thumb">
                                            <?php $__currentLoopData = $imageUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="single-slide">
                                                    <img class="img-responsive" src="<?php echo e(asset($imageUrl)); ?>" alt="">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-pro-desc">
                                    <div class="single-pro-content">
                                        <h5 class="ec-single-title"><?php echo e($product->name); ?></h5>
                                        <div class="ec-single-price-stoke">
                                            <div class="ec-single-price">
                                                <span class="new-price"><?php echo e(number_format($product->price, 0)); ?> Tk</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Single product content End -->
                    <!-- Single product tab start -->
                    <div class="ec-single-pro-tab">
                        <div class="ec-single-pro-tab-wrapper">
                            <div class="ec-single-pro-tab-nav">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#ec-spt-nav-details"
                                            role="tablist">Product Detail</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content  ec-single-pro-tab-content">
                                <div id="ec-spt-nav-details" class="tab-pane fade show active">
                                    <div class="ec-single-pro-tab-desc">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Title</th>
                                                    <th scope="col">Description</th>
                                            </thead>
                                            <tbody style="font-size: 14px;">
                                                <?php
                                                    $titles = explode(',', $product['description_title']);
                                                    $details = explode(',', $product['description_detail']);
                                                ?>

                                                <?php for($i = 0; $i < count($titles); $i++): ?>
                                                    <tr>
                                                        <td class="border"><?php echo e($titles[$i]); ?> </td>
                                                        <td><?php echo $details[$i]; ?></td>
                                                    </tr>
                                                <?php endfor; ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- product details description area end -->
                </div>
                <!-- Sidebar Area Start -->
                <div class="ec-pro-leftside ec-common-leftside col-lg-3 order-lg-first col-md-12 order-md-last">
                    <div class="ec-sidebar-wrap">
                        <!-- Sidebar Category Block -->
                        <div class="ec-sidebar-block">
                            <div class="ec-sb-title">
                                <h3 class="ec-sidebar-title">Brands</h3>
                            </div>
                            <div class="ec-sb-block-content">
                                <ul>

                                    <li>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="ec-sidebar-block-item"><?php echo e($brand->name); ?></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- Sidebar Category Block -->
                    </div>
                </div>
                <!-- Sidebar Area Start -->
            </div>
        </div>
    </section>
    <!-- End Single product -->

    <!-- Related Product Start -->
    <section class="section ec-releted-product section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title">
                        <h2 class="ec-bg-title">Related products</h2>
                        <h2 class="ec-title">Related products</h2>
                        <p class="sub-title">Browse The Collection of Top Products</p>
                    </div>
                </div>
            </div>
            <div class="row margin-minus-b-30">
                <!-- Related Product Content -->
                <?php $__currentLoopData = $relatedProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-6 ec-product-content">
                        <div class="ec-product-inner">
                            <div class="ec-product-hover"></div>
                            <div class="ec-pro-image-outer">
                                <div class="ec-pro-image">
                                    <a href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>" class="image">
                                        <img class="main-image" src="<?php echo e(asset(explode(',', $product->image)[0])); ?>"
                                            alt="Product" />
                                        <?php if(count(explode(',', $product->image)) > 1): ?>
                                            <img class="hover-image" src="<?php echo e(asset(explode(',', $product->image)[1])); ?>"
                                                alt="Product" />
                                        <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                            <div class="ec-pro-content">
                                <h5 class="ec-pro-title"><a
                                        href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>"><?php echo e($product->name); ?></a>
                                </h5>
                                <h6 class="ec-pro-stitle"><a
                                        href="shop-left-sidebar-col-3.html"><?php echo e($product->category->name); ?></a>
                                </h6>
                                <div class="ec-pro-rat-price">
                                    <div class="ec-pro-rat-pri-inner">
                                        <span class="ec-price">
                                            <span class="new-price"><?php echo e($product->price); ?>TK</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Related Product end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.blog.masterBlog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/website/product/productDetail.blade.php ENDPATH**/ ?>