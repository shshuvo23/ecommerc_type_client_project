<?php $__env->startSection('body'); ?>
    <div class="container">
        <!-- Shop content Start -->
        <div class="shop-pro-content">
            <div class="shop-pro-inner">
                <div class="row">
                    <?php if(count($products) > 0): ?>
                        <h1>Search results for "<?php echo e($query); ?>"</h1>
                        <ul>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 mb-6 col-5 pro-gl-content">
                                    <div class="ec-product-inner">
                                        <div class="ec-pro-image-outer">
                                            <div class="ec-pro-image">
                                                <a href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>"
                                                    class="image">
                                                    <img class="main-image"
                                                        src="<?php echo e(asset(explode(',', $product->image)[0])); ?>"
                                                        alt="Product" />
                                                    <?php if(count(explode(',', $product->image)) > 1): ?>
                                                        <img class="hover-image"
                                                            src="<?php echo e(asset(explode(',', $product->image)[1])); ?>"
                                                            alt="Product" />
                                                    <?php endif; ?>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="ec-pro-content">
                                            <h5 class="ec-pro-title"><a
                                                    href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>"><?php echo e($product->name); ?></a></h5>
                                            <span class="ec-price">
                                                <span class="new-price"><?php echo e($product->price); ?>Tk</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <h1>No results found for "<?php echo e($query); ?>" Search again with correct keyword</h1>
                    <?php endif; ?>

                </div>
            </div>
            <!-- Ec Pagination Start -->
            
            <!-- Ec Pagination End -->
        </div>
        <!--Shop content End -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.blog.masterBlog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/website/product/productSearch.blade.php ENDPATH**/ ?>