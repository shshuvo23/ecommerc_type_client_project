<?php $__env->startSection('title'); ?>
    User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sectionname'); ?>
    User-list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">User</h4>
            <h6 class="card-subtitle">All User List</h6>
            <div class="table-responsive m-t-40">
                <table id="example23" class="display nowrap table table-hover table-striped border" cellspacing="0"
                    width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>User Role</th>
                            <th>Atcion</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>User Role</th>
                            <th>Atcion</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if($user->usertype == 1): ?>
                                        Admin
                                    <?php else: ?>
                                        Customer
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($user instanceof \App\Models\User): ?>
                                        <!-- Check if the record is a customer -->
                                        <div class="col-md-6">
                                            <a href="<?php echo e(route('user.makeAdmin', ['id' => $user->id])); ?>"
                                                class="badge rounded-pill bg-info">Make Admin</a>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/admin/user/userList.blade.php ENDPATH**/ ?>