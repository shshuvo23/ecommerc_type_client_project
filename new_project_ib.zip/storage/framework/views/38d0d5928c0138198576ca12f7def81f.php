<?php $__env->startSection('title'); ?>
    Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sectionname'); ?>
    Product List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Product</h4>
            <h6 class="card-subtitle">Product List</h6>
            <div class="table-responsive m-t-40">
                <table id="example23" class="display nowrap table table-hover table-striped border" cellspacing="0"
                    width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Atcion</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Atcion</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($blog->title); ?></td>
                            <td>
                                <div style=" height: 100px; width: 300px; overflow: hidden; text-overflow: ellipsis;">
                                    <?php echo substr($blog->long_description, 0, 300) . '...'; ?>

                                </div>
                            </td>
                            <td>
                                <div>
                                        <img src="<?php echo e(asset($blog->image)); ?>" alt="<?php echo e($blog->title); ?> image" height="150" width="150">
                                </div>
                            </td>
                            <td>
                                <!-- Check if the record is a customer -->
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('employee.blog-edit', ['id' => $blog->id])); ?>" class="badge rounded-pill bg-info">Edit</a>
                                    <a href="<?php echo e(route('employee.blog-delete', ['id' => $blog->id])); ?>" class="badge rounded-pill bg-info">Delete</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/employee/blog/blogList.blade.php ENDPATH**/ ?>