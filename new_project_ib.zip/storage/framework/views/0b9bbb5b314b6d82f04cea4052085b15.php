<?php $__env->startSection('body'); ?>
    <!-- Main Slider Start -->
    <div class="ec-main-slider section ">
        <div class="ec-slider">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ec-slide-item d-flex slide-1">
                    <img src="<?php echo e(asset($slider->image)); ?>" alt="">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Main Slider End -->

    <!-- Ec Brand Section Start -->
    <section class="section ec-brand-section section-space-ptb-100">
        <div class="container">
            <div class="row">
                <div class="">
                    <h1 class="ec-title mb-5 mx-5">Brands</h1>
                </div>
                <div class="ec-brand-outer">
                    <ul class="ec-brand-inner">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ec-brand-item col-lg-2 col-md-4 col-sm-4">
                                <div class="ec-brand-img"><a href="<?php echo e(route('brand.show-product', ['id' => $brand->id])); ?>"><img alt="brand" title="brand"
                                            src="<?php echo e(asset($brand->image)); ?>" /></a></div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Ec Brand Section End -->

    <!-- Product tab Area Start -->
    <section class="section ec-product-tab section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title-block">
                    <div class="section-title">
                        <h2 class="ec-title">Featured Products</h2>
                    </div>
                </div>

            </div>
            <div class="row m-tb-minus-15">
                <div class="col">
                    <div class="tab-content">
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-2 col-md-6 col-sm-6 col-xs-6 ec-product-content">
                                    <div class="ec-product-inner">
                                        <div class="ec-product-hover"></div>
                                        <div class="ec-pro-image-outer">
                                            <div class="ec-pro-image">
                                                <a href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>"
                                                    class="image">
                                                    <img class="main-image"
                                                        src="<?php echo e(asset(explode(',', $product->image)[0])); ?>"
                                                        alt="Product" />
                                                    <?php if(count(explode(',', $product->image)) > 1): ?>
                                                        <img class="hover-image"
                                                            src="<?php echo e(asset(explode(',', $product->image)[1])); ?>"
                                                            alt="Product" />
                                                    <?php else: ?>
                                                        <img class="main-image"
                                                            src="<?php echo e(asset(explode(',', $product->image)[0])); ?>"
                                                            alt="Product" />
                                                    <?php endif; ?>

                                                </a>
                                            </div>
                                        </div>
                                        <div class="ec-pro-content">
                                            <h5 class="ec-pro-title"><a
                                                    href="<?php echo e(route('product.detail', ['id' => $product->id])); ?>"><?php echo e($product->name); ?></a>
                                            </h5>
                                            <h6 class="ec-pro-stitle"><a
                                                    href="shop-left-sidebar-col-3.html"><?php echo e($product->category->name); ?></a>
                                            </h6>
                                            <div class="ec-pro-rat-price">
                                                <div class="ec-pro-rat-pri-inner">
                                                    <span class="ec-price">
                                                        <span class="new-price"><?php echo e(number_format($product->price, 0)); ?> Tk</span>
                                                    </span>
                                                    <span class="ec-price">
                                                        <span class="new-price"><?php echo e(number_format($product->price, 0)); ?> Tk</span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ec Product tab Area End -->
    <!-- START Blog Style -->
    <section class="ec-card-blog section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title mb-3">
                        <h2 class="ec-title">Blog</h2>
                    </div>
                </div>
            </div>
            <div class="row margin-minus-t-15">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <article class="ec-full-blog">
                            <div class="ec-card-bg">
                                <div class="ec-wrapper">
                                    <div class="ec-card-main bg-img-1">
                                        <div class="ec-card-layer">
                                            <img src="<?php echo e(asset($blog->image)); ?>"
                                                alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="ec-card-head">
                                <span class="ec-date-box">
                                    <span class="ec-date-day"> <?php echo e($blog->created_at->format('d')); ?></span>
                                    <span class="ec-date-month"> <?php echo e($blog->created_at->format('F')); ?></span>
                                </span>
                            </div>
                            <div class="ec-card-info">
                                <h5><?php echo e($blog->title); ?></h5>
                                <a href="<?php echo e(route('blog.detail',['id' => $blog->id])); ?>" class="btn btn-with-icon">READ MORE</a>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <!--/END Blog Style -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\new_project_ib\resources\views/website/home/index.blade.php ENDPATH**/ ?>