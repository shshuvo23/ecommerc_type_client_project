@extends('admin.master')

@section('title')
Admin DashBoard
@endsection

@section('body')
<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Info box Content -->
<!-- ============================================================== -->
<div class="row">
    <!-- Column -->
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"></h4>
                <div class="text-end"> <span class="text-muted">Admin DashBoard</span>

                </div>
            </div>
        </div>
    </div>

@endsection
